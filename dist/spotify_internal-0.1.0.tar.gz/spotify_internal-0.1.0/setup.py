# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spotify_internal']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'spotify-internal',
    'version': '0.1.0',
    'description': 'A Python wrapper around the Spotify Internal API which can let users login with their login creds (and not OAuth)',
    'long_description': '',
    'author': 'addyett',
    'author_email': 'g.aditya2048@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
